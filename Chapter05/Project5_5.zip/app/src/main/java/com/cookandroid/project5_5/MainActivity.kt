package com.cookandroid.project5_5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    // ex5_15
    // 숫자 버튼을 제외한 activity_main.xml의 7개 위젯에 대응할 위젯 변수 7개
    lateinit internal var edit1 : EditText
    lateinit internal var edit2 : EditText
    lateinit internal var btnAdd : Button
    lateinit internal var btnSub : Button
    lateinit internal var btnMul : Button
    lateinit internal var btnDiv : Button
    lateinit internal var textResult : TextView
    // 입력될 2개의 문자열을 저장할 문자열 변수 2개
    lateinit internal var num1 : String
    lateinit internal var num2 : String
    // 계산 결과를 저장할 졍수 변수 1개
    internal var result : Int? = null
    // 10개 숫자 버튼을 저장할 버튼 배열
    internal var numButtons = ArrayList<Button>(10)
    // 10개 벼튼의 id를 저장할 정수형 배열
    internal var numBtnIDs = arrayOf(R.id.BtnNum0, R.id.BtnNum1, R.id.BtnNum2, R.id.BtnNum3,
        R.id.BtnNum4, R.id.BtnNum5, R.id.BtnNum6, R.id.BtnNum7,
        R.id.BtnNum8, R.id.BtnNum9)
    // 증가값 용도
    internal var I : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ex5_16
        edit1 = findViewById<EditText>(R.id.Edit1)
        edit2 = findViewById<EditText>(R.id.Edit2)
        btnAdd = findViewById<Button>(R.id.BtnAdd)
        btnSub = findViewById<Button>(R.id.BtnSub)
        btnMul = findViewById<Button>(R.id.BtnMul)
        btnDiv = findViewById<Button>(R.id.BtnDiv)
        textResult = findViewById<TextView>(R.id.TextResult)

        btnAdd.setOnTouchListener { view, motionEvent ->
            num1 = edit1.text.toString()
            num2 = edit2.text.toString()
            result = Integer.parseInt(num1) + Integer.parseInt(num2)
            textResult.text = "계산 결과: " + result.toString()
            false
        }
        btnSub.setOnTouchListener { view, motionEvent ->
            num1 = edit1.text.toString()
            num2 = edit2.text.toString()
            result = Integer.parseInt(num1) - Integer.parseInt(num2)
            textResult.text = "계산 결과: " + result.toString()
            false
        }
        btnMul.setOnTouchListener { view, motionEvent ->
            num1 = edit1.text.toString()
            num2 = edit2.text.toString()
            result = Integer.parseInt(num1) * Integer.parseInt(num2)
            textResult.text = "계산 결과: " + result.toString()
            false
        }
        btnDiv.setOnTouchListener { view, motionEvent ->
            num1 = edit1.text.toString()
            num2 = edit2.text.toString()
            result = Integer.parseInt(num1) / Integer.parseInt(num2)
            textResult.text = "계산 결과: " + result.toString()
            false
        }

        // ex5_17
        for (i in 0..9 step 1) {
            numButtons.add(findViewById<Button>(numBtnIDs[i]))
        }
        for (i in 0..numButtons.size - 1 step 1) {
            numButtons[i].setOnClickListener {
                if (edit1.isFocused) {
                    num1 = edit1.text.toString() + numButtons[i].text.toString()
                    edit1.setText(num1)
                } else if (edit2.isFocused) {
                    num2 = edit2.text.toString() + numButtons[i].text.toString()
                    edit2.setText(num2)
                } else {
                    Toast.makeText(applicationContext, "먼저 에디트텍스트를 선택하세요.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
