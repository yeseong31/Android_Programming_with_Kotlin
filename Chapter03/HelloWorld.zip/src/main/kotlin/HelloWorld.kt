fun main() {
    println("안드로이드를 위한 Kotlin 연습")
}